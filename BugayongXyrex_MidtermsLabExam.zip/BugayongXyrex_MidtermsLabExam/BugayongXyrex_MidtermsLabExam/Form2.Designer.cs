﻿namespace BugayongXyrex_MidtermsLabExam
{
    partial class StudentPage_Individual
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(StudentPage_Individual));
            StudentInformationLabel = new Label();
            StudentIdLabel = new Label();
            FullNameLabel = new Label();
            AddressLabel = new Label();
            BirthdateLabel = new Label();
            AgeLabel = new Label();
            ContactNoLabel = new Label();
            EmailAddressLabel = new Label();
            GuardianNameLabel = new Label();
            HoibbiesLabel = new Label();
            NicknameLabel = new Label();
            CourseLabel = new Label();
            YearLabel = new Label();
            SuspendLayout();
            // 
            // StudentInformationLabel
            // 
            StudentInformationLabel.AutoSize = true;
            StudentInformationLabel.Font = new Font("Segoe UI", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            StudentInformationLabel.Location = new Point(293, 46);
            StudentInformationLabel.Name = "StudentInformationLabel";
            StudentInformationLabel.Size = new Size(215, 30);
            StudentInformationLabel.TabIndex = 0;
            StudentInformationLabel.Text = "Student Information";
            // 
            // StudentIdLabel
            // 
            StudentIdLabel.AutoSize = true;
            StudentIdLabel.Font = new Font("Segoe UI Semibold", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            StudentIdLabel.Location = new Point(135, 132);
            StudentIdLabel.Name = "StudentIdLabel";
            StudentIdLabel.Size = new Size(81, 20);
            StudentIdLabel.TabIndex = 1;
            StudentIdLabel.Text = "Student ID";
            // 
            // FullNameLabel
            // 
            FullNameLabel.AutoSize = true;
            FullNameLabel.Font = new Font("Segoe UI Semibold", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            FullNameLabel.Location = new Point(135, 168);
            FullNameLabel.Name = "FullNameLabel";
            FullNameLabel.Size = new Size(79, 20);
            FullNameLabel.TabIndex = 2;
            FullNameLabel.Text = "Full Name";
            // 
            // AddressLabel
            // 
            AddressLabel.AutoSize = true;
            AddressLabel.Font = new Font("Segoe UI Semibold", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            AddressLabel.Location = new Point(135, 204);
            AddressLabel.Name = "AddressLabel";
            AddressLabel.Size = new Size(63, 20);
            AddressLabel.TabIndex = 10;
            AddressLabel.Text = "Address";
            // 
            // BirthdateLabel
            // 
            BirthdateLabel.AutoSize = true;
            BirthdateLabel.Font = new Font("Segoe UI Semibold", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            BirthdateLabel.Location = new Point(135, 240);
            BirthdateLabel.Name = "BirthdateLabel";
            BirthdateLabel.Size = new Size(72, 20);
            BirthdateLabel.TabIndex = 11;
            BirthdateLabel.Text = "Birthdate";
            // 
            // AgeLabel
            // 
            AgeLabel.AutoSize = true;
            AgeLabel.Font = new Font("Segoe UI Semibold", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            AgeLabel.Location = new Point(135, 276);
            AgeLabel.Name = "AgeLabel";
            AgeLabel.Size = new Size(36, 20);
            AgeLabel.TabIndex = 12;
            AgeLabel.Text = "Age";
            // 
            // ContactNoLabel
            // 
            ContactNoLabel.AutoSize = true;
            ContactNoLabel.Font = new Font("Segoe UI Semibold", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            ContactNoLabel.Location = new Point(135, 312);
            ContactNoLabel.Name = "ContactNoLabel";
            ContactNoLabel.Size = new Size(90, 20);
            ContactNoLabel.TabIndex = 13;
            ContactNoLabel.Text = "Contact No.";
            // 
            // EmailAddressLabel
            // 
            EmailAddressLabel.AutoSize = true;
            EmailAddressLabel.Font = new Font("Segoe UI Semibold", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            EmailAddressLabel.Location = new Point(135, 348);
            EmailAddressLabel.Name = "EmailAddressLabel";
            EmailAddressLabel.Size = new Size(104, 20);
            EmailAddressLabel.TabIndex = 14;
            EmailAddressLabel.Text = "Email Address";
            // 
            // GuardianNameLabel
            // 
            GuardianNameLabel.AutoSize = true;
            GuardianNameLabel.Font = new Font("Segoe UI Semibold", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            GuardianNameLabel.Location = new Point(135, 384);
            GuardianNameLabel.Name = "GuardianNameLabel";
            GuardianNameLabel.Size = new Size(125, 20);
            GuardianNameLabel.TabIndex = 15;
            GuardianNameLabel.Text = "Guardian's Name";
            // 
            // HoibbiesLabel
            // 
            HoibbiesLabel.AutoSize = true;
            HoibbiesLabel.Font = new Font("Segoe UI Semibold", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            HoibbiesLabel.Location = new Point(135, 456);
            HoibbiesLabel.Name = "HoibbiesLabel";
            HoibbiesLabel.Size = new Size(65, 20);
            HoibbiesLabel.TabIndex = 17;
            HoibbiesLabel.Text = "Hobbies";
            // 
            // NicknameLabel
            // 
            NicknameLabel.AutoSize = true;
            NicknameLabel.Font = new Font("Segoe UI Semibold", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            NicknameLabel.Location = new Point(135, 492);
            NicknameLabel.Name = "NicknameLabel";
            NicknameLabel.Size = new Size(78, 20);
            NicknameLabel.TabIndex = 18;
            NicknameLabel.Text = "Nickname";
            // 
            // CourseLabel
            // 
            CourseLabel.AutoSize = true;
            CourseLabel.Font = new Font("Segoe UI Semibold", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            CourseLabel.Location = new Point(543, 168);
            CourseLabel.Name = "CourseLabel";
            CourseLabel.Size = new Size(56, 20);
            CourseLabel.TabIndex = 19;
            CourseLabel.Text = "Course";
            // 
            // YearLabel
            // 
            YearLabel.AutoSize = true;
            YearLabel.Font = new Font("Segoe UI Semibold", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            YearLabel.Location = new Point(543, 132);
            YearLabel.Name = "YearLabel";
            YearLabel.Size = new Size(78, 20);
            YearLabel.TabIndex = 20;
            YearLabel.Text = "Year Level";
            // 
            // StudentPage_Individual
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 630);
            Controls.Add(YearLabel);
            Controls.Add(CourseLabel);
            Controls.Add(NicknameLabel);
            Controls.Add(HoibbiesLabel);
            Controls.Add(GuardianNameLabel);
            Controls.Add(EmailAddressLabel);
            Controls.Add(ContactNoLabel);
            Controls.Add(AgeLabel);
            Controls.Add(BirthdateLabel);
            Controls.Add(AddressLabel);
            Controls.Add(FullNameLabel);
            Controls.Add(StudentIdLabel);
            Controls.Add(StudentInformationLabel);
            Icon = (Icon)resources.GetObject("$this.Icon");
            Name = "StudentPage_Individual";
            Text = "Student Page Individual";
            Load += StudentPage_Individual_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label StudentInformationLabel;
        private Label StudentIdLabel;
        private Label FullNameLabel;
        private Label MiddleNameLabel;
        private Label HouseNoLabel;
        private Label BarangayNameLabel;
        private Label MunicipalityNameLabel;
        private Label ProvinceNameLabel;
        private Label RegionNameLabel;
        private Label AddressLabel;
        private Label BirthdateLabel;
        private Label AgeLabel;
        private Label ContactNoLabel;
        private Label EmailAddressLabel;
        private Label GuardianNameLabel;
        private Label HoibbiesLabel;
        private Label NicknameLabel;
        private Label CourseLabel;
        private Label YearLabel;
    }
}